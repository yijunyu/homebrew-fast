#!/bin/bash

# test framework
source $(dirname "$0")/framework_test.sh

# functionality missing
exit 1
