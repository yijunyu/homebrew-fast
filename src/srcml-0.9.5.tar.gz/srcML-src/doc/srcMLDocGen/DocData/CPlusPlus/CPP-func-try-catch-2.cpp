int f(int n) try {

} catch(...) {

}