const_cast<int const&>(*x);
