class Foo{
	Foo()
		:x(5)
	{ }
};