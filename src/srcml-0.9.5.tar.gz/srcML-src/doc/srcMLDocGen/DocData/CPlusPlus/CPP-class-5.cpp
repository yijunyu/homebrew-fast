class Foo {
	Foo() { }
};