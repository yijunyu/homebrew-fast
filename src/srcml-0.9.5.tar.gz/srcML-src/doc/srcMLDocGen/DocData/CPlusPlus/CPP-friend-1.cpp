class Matrix {
	friend Vector operator*(const Matrix&, const Vector&);
};