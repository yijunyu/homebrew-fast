class Foo {
	Foo() = default;
};