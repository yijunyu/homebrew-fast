class Foo {
protected:
};