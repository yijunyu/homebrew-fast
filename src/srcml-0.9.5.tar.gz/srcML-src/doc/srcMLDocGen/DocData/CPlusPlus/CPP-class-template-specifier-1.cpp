template<class T>
class Foo { };