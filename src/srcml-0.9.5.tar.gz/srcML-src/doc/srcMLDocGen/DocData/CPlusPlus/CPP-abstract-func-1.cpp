struct Foo {
	virtual void dump() const = 0;
};