class Foo{ 
	explicit Foo(X const& x);
};