class Foo
{
	
};