class Foo {
	~Foo();
}