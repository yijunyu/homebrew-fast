class Foo {
public:
protected:
private:
};