class Foo
	:Bar1, OtherBar
{ };