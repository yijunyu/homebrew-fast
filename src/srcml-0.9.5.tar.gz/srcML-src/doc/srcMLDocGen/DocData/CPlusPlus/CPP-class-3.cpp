class Foo
	:public bar
{ };