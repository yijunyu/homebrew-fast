class Foo {
	~Foo();
};