__asm { __asm mov al, 2  __asm mov dx, 0xD007 __asm out dx, al }
