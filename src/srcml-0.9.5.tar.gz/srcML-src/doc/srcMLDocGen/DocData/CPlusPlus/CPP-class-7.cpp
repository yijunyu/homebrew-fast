class Foo {
	~Foo() { }
};