struct Foo {
private:
};