class Foo
	:private Bar
{ };