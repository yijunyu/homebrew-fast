enum class Color {RED, GREEN, BLUE};
