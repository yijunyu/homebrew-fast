class Foo {
	Foo();
};