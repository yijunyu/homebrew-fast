Foo::Foo()
	:x(5)
{ }