class Foo {
	foo();
}