restrict double* x;
restrict union Z* x;