struct employee
{
    char name[20];
    int id;
    long cls;
} temp;