_Atomic union X t;

_Atomic (struct X) t;
_Atomic struct X t;
