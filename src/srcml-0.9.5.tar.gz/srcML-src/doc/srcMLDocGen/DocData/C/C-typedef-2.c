typedef struct club 
{
    char name[30];
    int size, year;
} GROUP;