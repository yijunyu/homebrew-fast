struct STUDENT sortstu( STUDENT a, STUDENT b ) {
    struct STUDENT x;
    return x;
}