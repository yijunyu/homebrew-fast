a = x[5];
val = matrix[x][y];