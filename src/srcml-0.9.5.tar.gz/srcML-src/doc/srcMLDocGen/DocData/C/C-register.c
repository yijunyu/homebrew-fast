register int x;
register float y;