if ( i > 0 )
    y = x / i;
else 
{
    x = i;
    y = f( x );
}