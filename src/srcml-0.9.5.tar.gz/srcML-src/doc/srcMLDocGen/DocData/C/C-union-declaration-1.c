union sign
{
    int svar;
    unsigned uvar;
} number;