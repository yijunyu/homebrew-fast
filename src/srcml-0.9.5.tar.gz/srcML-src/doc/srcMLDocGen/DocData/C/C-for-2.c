for (i = 0; i < max; i++ ) 
{
  if ( line[i] == ' ' )
  {
      space++;
  }
  if ( line[i] == '\t' )
  {
      tab++;
  }
}