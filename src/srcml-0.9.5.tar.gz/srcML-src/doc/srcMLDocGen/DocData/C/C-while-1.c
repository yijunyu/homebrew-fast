while ( i >= 0 ) 
{
    string1[i] = string2[i];
    i--;
}
