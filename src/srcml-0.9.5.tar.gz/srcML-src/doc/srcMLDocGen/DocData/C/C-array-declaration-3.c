struct {
    float x, y;
} complex[100];