struct STUDENT sortstu( STUDENT a, STUDENT b );
void print(STUDENT a);