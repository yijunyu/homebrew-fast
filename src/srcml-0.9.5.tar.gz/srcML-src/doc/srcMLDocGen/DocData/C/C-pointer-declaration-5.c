int(*X)(void);
int(*X)(int, float);
int(*X)(char const*,...);