int func(a, b, c)
   int a;
   int b;
   int c;
{ }