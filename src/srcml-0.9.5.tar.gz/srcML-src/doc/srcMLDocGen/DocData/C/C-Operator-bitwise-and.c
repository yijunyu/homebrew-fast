value = lhsExpr & rhsExpr;
