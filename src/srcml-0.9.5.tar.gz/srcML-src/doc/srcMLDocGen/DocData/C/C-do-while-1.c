do {
    y = f( x );
    x--;
} while ( x > 0 );