if ( i > 0 ) {
    y = x / i;
}
