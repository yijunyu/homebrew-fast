 {
    line[i] = x;
    x++;
    i--;
}