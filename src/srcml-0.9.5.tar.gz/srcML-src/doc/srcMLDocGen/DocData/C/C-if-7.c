else if( i < 0)
	x = q;
else 
    x = j;
    
