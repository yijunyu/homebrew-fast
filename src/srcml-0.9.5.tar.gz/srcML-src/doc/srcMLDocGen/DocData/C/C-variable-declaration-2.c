struct X y;
