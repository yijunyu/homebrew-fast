struct mybitfields
{
    int a : 5;
} test;