a ? x : y;
