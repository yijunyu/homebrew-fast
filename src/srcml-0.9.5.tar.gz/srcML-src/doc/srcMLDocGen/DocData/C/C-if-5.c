if ( i > 0 ) 
{                      /* With braces */
    if ( j > i )
        x = j;
}
else
    x = i;