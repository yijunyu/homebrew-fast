struct a {
    int x;
    double y;
    float z;
 };