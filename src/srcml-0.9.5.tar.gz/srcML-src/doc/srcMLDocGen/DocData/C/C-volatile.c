volatile int foo; 
int volatile foo;