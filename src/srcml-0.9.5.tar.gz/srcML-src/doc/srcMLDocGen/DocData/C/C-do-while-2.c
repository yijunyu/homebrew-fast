do x--; while ( x > 0 );
