struct
{
    int x;
    int y;
} mystruct;