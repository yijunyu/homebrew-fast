typedef char C;
typedef unsigned int WORD;
typedef char * pChar;
typedef char field [50]; 
typedef char field, *field2; 