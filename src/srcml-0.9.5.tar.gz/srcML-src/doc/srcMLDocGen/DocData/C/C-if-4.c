if ( i > 0 )           /* Without braces */
    if ( j > i )
        x = j;
    else
        x = i;