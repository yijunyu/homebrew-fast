value = lhsExpr * rhsExpr;
