double x = 0.0;
int y = (int)x;
